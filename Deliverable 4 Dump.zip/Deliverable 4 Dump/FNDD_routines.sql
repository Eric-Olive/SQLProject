-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: FNDD
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `deliverer_view`
--

DROP TABLE IF EXISTS `deliverer_view`;
/*!50001 DROP VIEW IF EXISTS `deliverer_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `deliverer_view` AS SELECT 
 1 AS `OrderNumber`,
 1 AS `Customer`,
 1 AS `Restaurant`,
 1 AS `Address`,
 1 AS `Item`,
 1 AS `Location`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customer_view`
--

DROP TABLE IF EXISTS `customer_view`;
/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `customer_view` AS SELECT 
 1 AS `OrderNumber`,
 1 AS `Deliverer`,
 1 AS `Restaurant`,
 1 AS `Item`,
 1 AS `Location`,
 1 AS `PaymentMethod`,
 1 AS `Order Status`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `deliverer_view`
--

/*!50001 DROP VIEW IF EXISTS `deliverer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `deliverer_view` AS select `ordertable`.`idOrder` AS `OrderNumber`,`person`.`name` AS `Customer`,`restaurant`.`name` AS `Restaurant`,`restaurant`.`address` AS `Address`,`item`.`dish` AS `Item`,`deliverylocation`.`location` AS `Location` from (((((`ordertable` join `person`) join `restaurant`) join `item`) join `deliverylocation`) join `personorder` `po1`) where ((`po1`.`idPerson` = `person`.`idPerson`) and (`ordertable`.`idOrder` = `po1`.`idOrder`) and (`ordertable`.`idItem` = `item`.`idItem`) and (`ordertable`.`status` = 'PENDING') and (`item`.`idRestaurant` = `restaurant`.`idRestaurant`) and (`ordertable`.`idDeliveryLocation` = `deliverylocation`.`idDeliveryLocation`) and (`po1`.`personType` = 'Customer') and `po1`.`idOrder` in (select `personorder`.`idOrder` from `personorder` where (`personorder`.`idPerson` = 1001))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_view` AS select `ordertable`.`idOrder` AS `OrderNumber`,`person`.`name` AS `Deliverer`,`restaurant`.`name` AS `Restaurant`,`item`.`dish` AS `Item`,`deliverylocation`.`location` AS `Location`,`paymentmethod`.`type` AS `PaymentMethod`,`ordertable`.`status` AS `Order Status` from ((((((`ordertable` join `person`) join `restaurant`) join `item`) join `deliverylocation`) join `personorder` `po1`) join `paymentmethod`) where ((`po1`.`idPerson` = `person`.`idPerson`) and (`ordertable`.`idOrder` = `po1`.`idOrder`) and (`ordertable`.`idItem` = `item`.`idItem`) and (`item`.`idRestaurant` = `restaurant`.`idRestaurant`) and (`ordertable`.`idPaymentMethod` = `paymentmethod`.`idPaymentMethod`) and (`ordertable`.`idDeliveryLocation` = `deliverylocation`.`idDeliveryLocation`) and (`po1`.`personType` = 'Deliverer') and `po1`.`idOrder` in (select `personorder`.`idOrder` from `personorder` where (`personorder`.`idPerson` = 1003))) order by `ordertable`.`idOrder` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'FNDD'
--

--
-- Dumping routines for database 'FNDD'
--
/*!50003 DROP PROCEDURE IF EXISTS `Completed_Orders_From_Restaurant` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Completed_Orders_From_Restaurant`(IN restaurant_name VARCHAR(45))
BEGIN
SELECT OrderTable.idOrder,
	   Restaurant.name,
       Item.dish, 
       OrderTable.totalPrice, 
       OrderTable.status
FROM Restaurant, OrderTable, Item
WHERE Restaurant.name = restaurant_name
AND OrderTable.status = 'COMPLETE'
AND Restaurant.idRestaurant = Item.idRestaurant
AND Item.idItem = OrderTable.idItem;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 19:43:41
